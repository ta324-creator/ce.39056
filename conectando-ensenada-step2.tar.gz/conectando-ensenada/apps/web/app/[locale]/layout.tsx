import type { Metadata } from 'next'
import { NextIntlClientProvider } from 'next-intl'
import { getMessages, getTranslations } from 'next-intl/server'
import { notFound } from 'next/navigation'
import { routing } from '@/i18n/routing'
import '../globals.css'

// ─────────────────────────────────────────────────────────────────────────────
// Fonts
// PLACEHOLDER: Using system font stack until brand guidelines are finalized.
//
// To add a custom font in production:
//   import { Inter } from 'next/font/google'
//   const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
// Then add inter.variable to <html> className.
//
// The CSS variable --font-inter falls back gracefully to system-ui.
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// Metadata — SEO defaults (overridden by individual pages)
// ─────────────────────────────────────────────────────────────────────────────
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'meta' })

  const siteUrl =
    process.env.NEXT_PUBLIC_SITE_URL ?? 'https://conectandoensenada.org'

  return {
    metadataBase: new URL(siteUrl),
    title: {
      default: t('site_name'),
      template: `%s | ${t('site_name')}`,
    },
    description: t('site_description'),
    openGraph: {
      type: 'website',
      siteName: t('site_name'),
      locale: locale === 'en' ? 'en_US' : 'es_MX',
      alternateLocale: locale === 'en' ? ['es_MX'] : ['en_US'],
    },
    twitter: {
      card: 'summary_large_image',
    },
    alternates: {
      canonical: siteUrl,
      languages: {
        'es-MX': siteUrl,
        'en-US': `${siteUrl}/en`,
      },
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
  }
}

// Tell Next.js which locales to pre-render at build time
export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }))
}

// ─────────────────────────────────────────────────────────────────────────────
// Layout Component
// ─────────────────────────────────────────────────────────────────────────────
export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: Promise<{ locale: string }>
}) {
  const { locale } = await params

  // Validate locale — redirect unknown locales to 404
  if (!routing.locales.includes(locale as (typeof routing.locales)[number])) {
    notFound()
  }

  // Load all messages for this locale (passed to client components via provider)
  const messages = await getMessages()

  return (
    <html lang={locale} suppressHydrationWarning>
      {/*
        suppressHydrationWarning on <body> prevents false hydration mismatches
        from browser extensions that modify the DOM (e.g. password managers).
      */}
      <body suppressHydrationWarning>
        <NextIntlClientProvider messages={messages}>
          {/*
            Layout slots will be added here in Sprint 3:
            - <Header />
            - <main>{children}</main>
            - <Footer />

            For now, children render directly so the page structure
            is visible without interference.
          */}
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  )
}
