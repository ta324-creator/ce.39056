import { useTranslations } from 'next-intl'
import { getTranslations } from 'next-intl/server'
import type { Metadata } from 'next'

// ─────────────────────────────────────────────────────────────────────────────
// SEO metadata for the homepage
// ─────────────────────────────────────────────────────────────────────────────
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'home' })

  return {
    title: t('hero_title'),
    description: t('hero_subtitle'),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Directory sections — drives the navigation cards on the homepage.
// PLACEHOLDER: Icons and links will be wired to real routes in Sprint 3.
// ─────────────────────────────────────────────────────────────────────────────
const SECTIONS = [
  { key: 'businesses', emoji: '🏪', href: '/negocios', hrefEn: '/en/businesses' },
  { key: 'restaurants', emoji: '🍽️', href: '/restaurantes', hrefEn: '/en/restaurants' },
  { key: 'tourism', emoji: '🌊', href: '/turismo', hrefEn: '/en/tourism' },
  { key: 'beaches', emoji: '🏖️', href: '/playas', hrefEn: '/en/beaches' },
  { key: 'trails', emoji: '🥾', href: '/senderismo', hrefEn: '/en/hiking' },
  { key: 'events', emoji: '🎉', href: '/eventos', hrefEn: '/en/events' },
  { key: 'news', emoji: '📰', href: '/noticias', hrefEn: '/en/news' },
  { key: 'jobs', emoji: '💼', href: '/empleos', hrefEn: '/en/jobs' },
  { key: 'marketplace', emoji: '📦', href: '/clasificados', hrefEn: '/en/classifieds' },
  { key: 'real_estate', emoji: '🏠', href: '/bienes-raices', hrefEn: '/en/real-estate' },
] as const

// ─────────────────────────────────────────────────────────────────────────────
// Page Component
// ─────────────────────────────────────────────────────────────────────────────
export default function HomePage() {
  const t = useTranslations('home')
  const tNav = useTranslations('nav')

  return (
    <main
      style={{
        minHeight: '100vh',
        fontFamily: 'var(--font-sans)',
        background: 'var(--color-surface-raised)',
      }}
    >
      {/* ─── Hero ─────────────────────────────────────────────────────────── */}
      <section
        style={{
          background: 'var(--color-primary)',
          color: 'var(--color-primary-foreground)',
          padding: '4rem 1.5rem',
          textAlign: 'center',
        }}
      >
        <p
          style={{
            fontSize: '0.875rem',
            fontWeight: 600,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            opacity: 0.8,
            marginBottom: '0.5rem',
          }}
        >
          ConectandoEnsenada.org
        </p>
        <h1
          style={{
            fontSize: 'clamp(2rem, 5vw, 3.5rem)',
            fontWeight: 800,
            lineHeight: 1.15,
            marginBottom: '1rem',
            maxWidth: '700px',
            marginInline: 'auto',
          }}
        >
          {t('hero_title')}
        </h1>
        <p
          style={{
            fontSize: 'clamp(1rem, 2vw, 1.25rem)',
            opacity: 0.9,
            marginBottom: '2rem',
            maxWidth: '500px',
            marginInline: 'auto',
          }}
        >
          {t('hero_subtitle')}
        </p>

        {/*
          PLACEHOLDER: Search bar will be replaced with a real
          Supabase FTS-powered component in Sprint 3.
        */}
        <div
          style={{
            maxWidth: '560px',
            marginInline: 'auto',
            display: 'flex',
            gap: '0.5rem',
            background: 'white',
            borderRadius: 'var(--radius-xl)',
            padding: '0.375rem',
          }}
        >
          <input
            type="text"
            placeholder={t('hero_search_placeholder')}
            disabled
            style={{
              flex: 1,
              border: 'none',
              outline: 'none',
              padding: '0.625rem 1rem',
              fontSize: '1rem',
              color: 'var(--color-text-primary)',
              background: 'transparent',
              cursor: 'not-allowed',
            }}
          />
          <button
            disabled
            style={{
              background: 'var(--color-primary)',
              color: 'white',
              border: 'none',
              borderRadius: 'var(--radius-lg)',
              padding: '0.625rem 1.25rem',
              fontWeight: 600,
              cursor: 'not-allowed',
              opacity: 0.7,
            }}
          >
            🔍
          </button>
        </div>
        <p
          style={{
            marginTop: '0.75rem',
            fontSize: '0.75rem',
            opacity: 0.6,
          }}
        >
          🚧 Search coming in Sprint 3
        </p>
      </section>

      {/* ─── Section Grid ─────────────────────────────────────────────────── */}
      <section
        style={{
          maxWidth: '1200px',
          marginInline: 'auto',
          padding: '3rem 1.5rem',
        }}
      >
        <h2
          style={{
            fontSize: '1.5rem',
            fontWeight: 700,
            marginBottom: '0.5rem',
            color: 'var(--color-text-primary)',
          }}
        >
          {t('sections_title')}
        </h2>
        <p
          style={{
            color: 'var(--color-text-secondary)',
            marginBottom: '2rem',
          }}
        >
          {t('sections_subtitle')}
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
            gap: '1rem',
          }}
        >
          {SECTIONS.map(({ key, emoji }) => (
            <div
              key={key}
              style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '1.5rem',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'box-shadow 0.2s ease, transform 0.2s ease',
                boxShadow: 'var(--shadow-card)',
              }}
            >
              <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>
                {emoji}
              </div>
              <div
                style={{
                  fontWeight: 600,
                  color: 'var(--color-text-primary)',
                  fontSize: '0.9375rem',
                }}
              >
                {tNav(key as Parameters<typeof tNav>[0])}
              </div>
              <div
                style={{
                  fontSize: '0.75rem',
                  color: 'var(--color-text-tertiary)',
                  marginTop: '0.25rem',
                }}
              >
                🚧 Próximamente
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── Dev Status Banner ─────────────────────────────────────────────── */}
      <div
        style={{
          background: '#fefce8',
          border: '1px solid #fde047',
          borderRadius: 'var(--radius-lg)',
          padding: '1rem 1.5rem',
          maxWidth: '800px',
          marginInline: 'auto',
          marginBottom: '3rem',
          fontSize: '0.875rem',
          color: '#713f12',
        }}
      >
        <strong>🚧 Development Mode</strong> — Step 2 complete. Infrastructure
        is live. Next: Step 3 (Supabase) → Step 4 (Vercel) → Step 5 (SQL
        migrations) → Sprint 3 (Business Directory).
      </div>
    </main>
  )
}
