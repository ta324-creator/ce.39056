import createMiddleware from 'next-intl/middleware'
import { type NextRequest, NextResponse } from 'next/server'
import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { routing } from '@/i18n/routing'

// Initialize the next-intl routing middleware
const handleI18nRouting = createMiddleware(routing)

export async function middleware(request: NextRequest) {
  // Run i18n routing first — it handles locale detection and redirects
  const response = handleI18nRouting(request)

  // Then refresh the Supabase auth session on every request.
  // This keeps the session alive without requiring the user to re-login.
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          // Write updated auth cookies to both the request and response
          cookiesToSet.forEach(({ name, value, options }) => {
            request.cookies.set(name, value)
            response.cookies.set(name, value, options)
          })
        },
      },
    }
  )

  // IMPORTANT: getUser() must be called (not getSession()) to validate
  // the JWT with Supabase servers. getSession() only reads the local cookie.
  await supabase.auth.getUser()

  return response
}

export const config = {
  // Run middleware on all routes except:
  // - Next.js internals (_next/static, _next/image)
  // - Static files (images, fonts, etc.)
  // - API routes under /api (handled separately)
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|api|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|woff|woff2)$).*)',
  ],
}
